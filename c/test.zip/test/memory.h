#ifndef memory_H
#define memory_H

void *memoryMalloc(unsigned int size);
void memoryFree(void *ptr);

#endif