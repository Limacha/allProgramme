#include "platform.h"
EventQueue eventQueue = {0};