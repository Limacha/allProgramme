#ifndef INPUT_H
#define INPUT_H

void initInput(void);
void processInput(void);
int isSpacePressed(void);
int isRunning(void);

#endif
