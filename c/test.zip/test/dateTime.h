#ifndef dateTime_H
#define dateTime_H

void getDate(unsigned short *year, unsigned short *month, unsigned short *day);
void getTime(unsigned short *hour, unsigned short *minute, unsigned short *second);

char *createDateChain();
char *createTimeChain();

#endif