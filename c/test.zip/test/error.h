#ifndef error_H
#define error_H

typedef struct
{
} Error;

#endif