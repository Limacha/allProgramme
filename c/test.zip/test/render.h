#ifndef RENDER_H
#define RENDER_H

void initRender(int w, int h);
void renderFrame(unsigned int *pixels);
void shutdownRender(void);

#endif
