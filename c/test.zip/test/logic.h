#ifndef LOGIC_H
#define LOGIC_H

void initLogic(int w, int h);
void updateLogic(void);
void shutdownLogic(void);
unsigned int *getPixels(void);

#endif
