# defaultWebSite
 un shema a copy paste avec un site minimaliste deja prefait  
 (node.js, sans bdd, avec un base.html et une architecture)
